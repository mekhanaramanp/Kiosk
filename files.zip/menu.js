// routes/menu.js — Menu browsing (public) + admin management
const router     = require('express').Router();
const db         = require('../config/db');
const { adminOnly, auth } = require('../middleware/auth');
const { body, validationResult } = require('express-validator');

const validate = (req, res, next) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) return res.status(400).json({ success: false, errors: errors.array() });
  next();
};

// ── GET /api/menu — all items, optional filters ────────────────────
// Query params: outlet (name or id), category, status, q (search)
router.get('/', async (req, res, next) => {
  try {
    const { outlet, category, status, q } = req.query;
    let sql = `
      SELECT mi.id, mi.name, o.name AS outlet, mi.category,
             mi.price, mi.emoji, mi.status, mi.stock_count,
             mi.description, mi.eta, mi.outlet_id
      FROM   menu_items mi
      JOIN   outlets o ON mi.outlet_id = o.id
    `;
    const where = []; const params = [];
    if (outlet) {
      isNaN(outlet)
        ? (where.push('o.name = ?'), params.push(outlet))
        : (where.push('o.id = ?'),   params.push(outlet));
    }
    if (category) { where.push('mi.category = ?'); params.push(category); }
    if (status)   { where.push('mi.status = ?');   params.push(status); }
    if (q) {
      where.push('(mi.name LIKE ? OR mi.description LIKE ? OR mi.category LIKE ?)');
      const like = `%${q}%`;
      params.push(like, like, like);
    }
    if (where.length) sql += ' WHERE ' + where.join(' AND ');
    sql += ' ORDER BY mi.category, mi.name';
    const [rows] = await db.query(sql, params);
    res.json({ success: true, data: rows });
  } catch (e) { next(e); }
});

// ── GET /api/menu/outlets — list all outlets ──────────────────────
router.get('/outlets', async (_req, res, next) => {
  try {
    const [rows] = await db.query('SELECT * FROM outlets ORDER BY id');
    res.json({ success: true, data: rows });
  } catch (e) { next(e); }
});

// ── GET /api/menu/:id — single item ───────────────────────────────
router.get('/:id', async (req, res, next) => {
  try {
    const [rows] = await db.query(`
      SELECT mi.*, o.name AS outlet
      FROM   menu_items mi JOIN outlets o ON mi.outlet_id = o.id
      WHERE  mi.id = ?
    `, [req.params.id]);
    if (!rows.length) return res.status(404).json({ success: false, error: 'Item not found' });
    res.json({ success: true, data: rows[0] });
  } catch (e) { next(e); }
});

// ── POST /api/menu — admin add item ───────────────────────────────
router.post('/',
  adminOnly,
  [
    body('name').notEmpty().trim(),
    body('outlet_id').isInt({ min: 1 }),
    body('category').isIn(['snacks','biscuits','drinks','colddrinks','icecream','morning','lunch','evening']),
    body('price').isInt({ min: 1 }),
    body('status').optional().isIn(['available','preparing','unavailable']),
  ],
  validate,
  async (req, res, next) => {
    try {
      const { name, outlet_id, category, price, emoji, status, stock_count, description, eta } = req.body;
      const [result] = await db.query(
        `INSERT INTO menu_items (name,outlet_id,category,price,emoji,status,stock_count,description,eta)
         VALUES (?,?,?,?,?,?,?,?,?)`,
        [name, outlet_id, category, price,
         emoji || '🍽️', status || 'available',
         stock_count || 0, description || '', eta || null]
      );
      res.status(201).json({ success: true, message: 'Item added', id: result.insertId });
    } catch (e) { next(e); }
  }
);

// ── PUT /api/menu/:id — admin update item ─────────────────────────
router.put('/:id',
  adminOnly,
  [
    body('price').optional().isInt({ min: 1 }),
    body('status').optional().isIn(['available','preparing','unavailable']),
    body('category').optional().isIn(['snacks','biscuits','drinks','colddrinks','icecream','morning','lunch','evening']),
  ],
  validate,
  async (req, res, next) => {
    try {
      const fields = ['name','outlet_id','category','price','emoji','status','stock_count','description','eta'];
      const updates = []; const values = [];
      fields.forEach(f => {
        if (req.body[f] !== undefined) { updates.push(`${f} = ?`); values.push(req.body[f]); }
      });
      if (!updates.length) return res.status(400).json({ success: false, error: 'Nothing to update' });
      values.push(req.params.id);
      await db.query(`UPDATE menu_items SET ${updates.join(', ')} WHERE id = ?`, values);
      res.json({ success: true, message: 'Item updated' });
    } catch (e) { next(e); }
  }
);

// ── DELETE /api/menu/:id — admin delete item ──────────────────────
router.delete('/:id', adminOnly, async (req, res, next) => {
  try {
    const [result] = await db.query('DELETE FROM menu_items WHERE id = ?', [req.params.id]);
    if (!result.affectedRows) return res.status(404).json({ success: false, error: 'Item not found' });
    res.json({ success: true, message: 'Item deleted' });
  } catch (e) { next(e); }
});

// ── PATCH /api/menu/:id/status — quick status toggle ─────────────
router.patch('/:id/status', adminOnly, async (req, res, next) => {
  try {
    const { status, stock_count, eta } = req.body;
    if (!status) return res.status(400).json({ success: false, error: 'status required' });
    await db.query(
      'UPDATE menu_items SET status=?, stock_count=IFNULL(?,stock_count), eta=IFNULL(?,eta) WHERE id=?',
      [status, stock_count ?? null, eta ?? null, req.params.id]
    );
    res.json({ success: true, message: 'Status updated' });
  } catch (e) { next(e); }
});

module.exports = router;

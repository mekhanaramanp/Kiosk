// routes/orders.js — Place orders, view history, admin manage
const router = require('express').Router();
const db     = require('../config/db');
const { auth, adminOnly } = require('../middleware/auth');
const { body, validationResult } = require('express-validator');

const validate = (req, res, next) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) return res.status(400).json({ success: false, errors: errors.array() });
  next();
};

// ── POST /api/orders — place order (authenticated user) ───────────
router.post('/',
  auth,
  [
    body('student_name').notEmpty().trim(),
    body('block').notEmpty().trim(),
    body('room').notEmpty().trim(),
    body('payment_method').isIn(['upi','cod']),
    body('items').isArray({ min: 1 }),
    body('items.*.menu_item_id').isInt({ min: 1 }),
    body('items.*.qty').isInt({ min: 1 }),
  ],
  validate,
  async (req, res, next) => {
    const conn = await db.getConnection();
    try {
      await conn.beginTransaction();

      const { student_name, block, room, payment_method, items } = req.body;

      // Fetch & validate all requested menu items
      const ids = items.map(i => i.menu_item_id);
      const [menuRows] = await conn.query(
        `SELECT mi.id, mi.name, mi.price, mi.emoji, mi.status, mi.stock_count,
                mi.outlet_id, o.name AS outlet_name
         FROM   menu_items mi JOIN outlets o ON mi.outlet_id = o.id
         WHERE  mi.id IN (?)`,
        [ids]
      );
      const menuMap = Object.fromEntries(menuRows.map(r => [r.id, r]));

      // Validate each requested item
      for (const req_item of items) {
        const m = menuMap[req_item.menu_item_id];
        if (!m) throw Object.assign(new Error(`Item #${req_item.menu_item_id} not found`), { status: 404 });
        if (m.status === 'unavailable')
          throw Object.assign(new Error(`"${m.name}" is currently unavailable`), { status: 409 });
        if (m.stock_count > 0 && m.stock_count < req_item.qty)
          throw Object.assign(new Error(`Only ${m.stock_count} units of "${m.name}" available`), { status: 409 });
      }

      // Build order
      const orderId  = 'ORD' + Date.now().toString().slice(-7);
      const subtotal = items.reduce((sum, i) => sum + menuMap[i.menu_item_id].price * i.qty, 0);
      const codFee   = payment_method === 'cod' ? 5 : 0;
      const total    = subtotal + 5 + codFee;  // ₹5 delivery always

      // Estimate ETA based on outlets in cart
      const outletIds = [...new Set(items.map(i => menuMap[i.menu_item_id].outlet_id))];
      const etaMins   = 10 + (outletIds.length - 1) * 5 + Math.floor(Math.random() * 8);
      const eta       = `~${etaMins} min`;

      await conn.query(
        `INSERT INTO orders (id,user_id,student_name,block,room,subtotal,delivery_fee,cod_fee,total,payment_method,eta_text)
         VALUES (?,?,?,?,?,?,5,?,?,?,?)`,
        [orderId, req.user.id, student_name, block, room, subtotal, codFee, total, payment_method, eta]
      );

      // Insert order items (trigger handles stock decrement)
      for (const req_item of items) {
        const m = menuMap[req_item.menu_item_id];
        await conn.query(
          `INSERT INTO order_items (order_id,menu_item_id,item_name,item_emoji,item_price,outlet_id,outlet_name,qty)
           VALUES (?,?,?,?,?,?,?,?)`,
          [orderId, m.id, m.name, m.emoji, m.price, m.outlet_id, m.outlet_name, req_item.qty]
        );
      }

      await conn.commit();
      res.status(201).json({
        success: true,
        message: 'Order placed!',
        data: { order_id: orderId, total, eta, payment_method },
      });
    } catch (e) {
      await conn.rollback();
      next(e);
    } finally {
      conn.release();
    }
  }
);

// ── GET /api/orders/my — current user's order history ─────────────
router.get('/my', auth, async (req, res, next) => {
  try {
    const [orders] = await db.query(`
      SELECT id, student_name, block, room, subtotal, delivery_fee, cod_fee,
             total, payment_method, status, eta_text, placed_at, delivered_at
      FROM   orders WHERE user_id = ? ORDER BY placed_at DESC
    `, [req.user.id]);

    // Attach items to each order
    for (const order of orders) {
      const [items] = await db.query(
        `SELECT oi.*, o.name AS outlet
         FROM   order_items oi JOIN outlets o ON oi.outlet_id = o.id
         WHERE  oi.order_id = ?`,
        [order.id]
      );
      order.items = items;
      // Build outlet groups (matching frontend structure)
      const groupMap = {};
      items.forEach(i => {
        if (!groupMap[i.outlet]) groupMap[i.outlet] = { outlet: i.outlet, items: [] };
        groupMap[i.outlet].items.push(i);
      });
      order.outlet_groups = Object.values(groupMap);
    }
    res.json({ success: true, data: orders });
  } catch (e) { next(e); }
});

// ── GET /api/orders/:id — single order ───────────────────────────
router.get('/:id', auth, async (req, res, next) => {
  try {
    const [[order]] = await db.query('SELECT * FROM orders WHERE id = ?', [req.params.id]);
    if (!order) return res.status(404).json({ success: false, error: 'Order not found' });
    // Only owner or admin can view
    if (order.user_id !== req.user.id && req.user.role !== 'admin')
      return res.status(403).json({ success: false, error: 'Access denied' });

    const [items] = await db.query(
      `SELECT oi.*, o.name AS outlet FROM order_items oi
       JOIN outlets o ON oi.outlet_id = o.id WHERE oi.order_id = ?`,
      [req.params.id]
    );
    order.items = items;
    res.json({ success: true, data: order });
  } catch (e) { next(e); }
});

// ── PATCH /api/orders/:id/status — admin update status ────────────
router.patch('/:id/status', adminOnly, async (req, res, next) => {
  try {
    const { status } = req.body;
    if (!['preparing','delivered','cancelled'].includes(status))
      return res.status(400).json({ success: false, error: 'Invalid status' });
    const [result] = await db.query('UPDATE orders SET status=? WHERE id=?', [status, req.params.id]);
    if (!result.affectedRows) return res.status(404).json({ success: false, error: 'Order not found' });
    res.json({ success: true, message: `Order marked ${status}` });
  } catch (e) { next(e); }
});

// ── GET /api/orders — admin: all orders ──────────────────────────
router.get('/', adminOnly, async (req, res, next) => {
  try {
    const { status, outlet } = req.query;
    let sql = `
      SELECT o.id, o.student_name, o.block, o.room, o.total,
             o.payment_method, o.status, o.eta_text, o.placed_at, u.email
      FROM   orders o JOIN users u ON o.user_id = u.id
    `;
    const where = []; const params = [];
    if (status) { where.push('o.status = ?'); params.push(status); }
    if (where.length) sql += ' WHERE ' + where.join(' AND ');
    sql += ' ORDER BY o.placed_at DESC';
    const [orders] = await db.query(sql, params);
    res.json({ success: true, data: orders });
  } catch (e) { next(e); }
});

module.exports = router;
